#ifndef __MATADD_H
#define __MATADD_H

void matadd(int m, int n, double **A, double **B, double **C);

#endif
